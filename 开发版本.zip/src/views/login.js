import {Alert, Button, Text, TextInput, TouchableHighlight, TouchableOpacity, useColorScheme, View} from "react-native";
import {useEffect, useRef, useState} from "react";
import {styles} from "../css";
import {_graphic, _Login, _name, _sms, _SmsLogin} from "../_Api";
import Canvas from 'react-native-canvas';
import * as React from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export function Login({navigation}) {
    navigation.addListener('focus', () => {
        navigation.setOptions({
            headerShown: false,
        })
        console.log('进入登陆')
    })
    navigation.addListener('blur', () => {
        console.log('退出登陆')
    })

    const colorScheme = useColorScheme();
    const C1 = colorScheme == 'light' ? styles.lightC1 : styles.darkC1
    const C2 = colorScheme == 'light' ? {color: '#696A80'} : styles.darkC2
    const Bbc = colorScheme == 'light' ? {borderColor: '#696A80'} : {borderColor: '#fff'}    //对话框颜色
    const MsgColorTouchable = colorScheme == 'light' ? '#EAEAEA' : '#333C52'    //点击对话框

    const [m, setM] = useState(0)   //验证码计时器
    const refM = useRef(m)
    refM.current = m

    const _Canvas = useRef(null)           // canvas控制器
    const [graphic,setGraphic] = useState('')   //获取图形验证码
    const [graphicB,setBGraphic] = useState(false)   //获取图形验证码

    const [end,setEnd] = useState(true)   //获取验证码
    const [tel,setTel] = useState(Number)   //电话
    const [code,setCode] = useState(null) //短信验证码
    const [codeBoolean,setCodeBoolean] = useState(false) //登陆严重状态




    //计时器
    const mFun = () => {
        setM(60)
        let intM = setInterval(() => {
            if (refM.current == 1) {
                clearInterval(intM)
                setEnd(false)
            }
            setM(refM.current - 1)
        }, 1000)
    }


    return <View style={[styles.Login, C1]}>
        <View style={[styles.LoginRow]}>
            <Text style={[styles.T1, styles.bold, C2, {marginBottom: 10}, {color: '#6A8DE2'}]}>电话登录 </Text>
            <Text style={[styles.T5, C2, {opacity: 0.9}, styles.bold]}>使用前请阅读 <Text
                style={styles.LoginRowColor}>《boatIM使用协议》</Text>，注册或使用代表您同意此协议。 </Text>

            <View style={{width: '60%', marginTop: 30}}>
                <Text style={[styles.T5, C2, styles.bold, {opacity: 0.9}]}><Text style={styles.LoginRed}>* </Text>输入电话号码</Text>
                <TextInput
                    defaultValue={tel}
                    editable={end}
                    keyboardType={'numeric'}
                    style={[C2, styles.LoginInputs, Bbc, styles.T5, {marginBottom: 6}]} value={tel}
                    returnKeyType={"done"}
                    onSubmitEditing={({nativeEvent: {text, eventCount, target}}) => {
                        let myreg = /^[1][3,4,5,7,8][0-9]{9}$/;
                        if (myreg.test(text)) {
                            _graphic(text,code=>{
                                setBGraphic(true)    //图形验证码
                                const ctx = _Canvas.current.getContext('2d');
                                ctx.fillStyle = '#FFFFFF';
                                ctx.fillRect(0, 0, 70, 27);
                                ctx.font = "20px arial";
                                ctx.strokeText(code, 5, 20);//画布上添加验证码
                                setTel(text)
                                setEnd(false)   //不可输入
                                console.log('图形验证码',code)
                            })



                        } else {
                            Alert.alert('号码错误', '输入的电话格式不对')
                        }
                    }}
                    onChangeText={text => setTel(text)}/>
            </View>

            {/*//图形验证码*/}
            {graphicB? <View  style={{width: '50%', marginTop: 20}}>
                <Text style={[styles.T5, C2, styles.bold, {opacity: 0.9}]}><Text style={styles.LoginRed}>* </Text>输入图形验证码</Text>
                <TextInput returnKeyType={"done"}
                           style={[C2, styles.LoginInputs, Bbc, styles.T5, {marginBottom: 6}]}
                           onChangeText={text=>setGraphic(text)}
                />
                {/*图形验证码*/}
                <Canvas ref={_Canvas} style={styles.canvas} width="60px" height="23px"/>
            </View>:''}

            {/*获取短信*/}
            {graphicB ?<TouchableOpacity onPress={()=>{
                _sms(tel,graphic,cb=>{
                    if(cb=='短信已发送'){
                        setCodeBoolean(true)
                        setBGraphic(false)
                        mFun()      //计时器起
                    }else {
                        Alert.alert(cb)
                    }
                })
            }}>
                <Text style={styles.loginBtn}>获取短信 </Text>
            </TouchableOpacity>:''}


            {/*code*/}
            {codeBoolean?<View style={{width: '40%', marginTop: 20}}>
                <Text style={[styles.T5, C2, styles.bold, {opacity: 0.9}]}><Text style={styles.LoginRed}>* </Text>输入短信验证码</Text>
                <TextInput style={[C2, styles.LoginInputs, Bbc, styles.T5, {marginBottom: 6}]}
                           returnKeyType={"done"}
                           value={code}
                           onChangeText={(text)=>setCode(text)}/>

                <View>
                    {m?<Text style={[styles.T6, C2, styles.bold,styles.LoginYe]}>{m}秒</Text>:
                        <TouchableOpacity onPress={() => _sms(tel,graphic,cb=>{
                            console.log(1111,cb)
                            if(cb=='短信已发送'){
                                setCodeBoolean(true)
                                setBGraphic(false)
                                mFun()      //计时器起
                            }else {
                                Alert.alert(cb)
                            }
                        })}>
                            <Text style={[styles.T6, C2, styles.bold]}>重新获取 </Text>
                        </TouchableOpacity>}
                </View>
            </View>:''}

            {/*code.length==6*/}
            {codeBoolean?<TouchableOpacity onPress={() => {
                console.log('code', code)
                _SmsLogin(tel,code,async user=> {
                    console.log('登陆信息', user)
                    if (user == '请核对验证码') {
                        Alert.alert(user)
                    } else {
                        navigation.navigate('List')
                    }
                })
            }}>
                <Text style={styles.loginBtn}>登  陆</Text>
            </TouchableOpacity>:''}


        </View>
    </View>
}
