//推送标题
import * as Notifications from "expo-notifications";


Notifications.setNotificationHandler({
    handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: false,
        shouldSetBadge: true,
    }),
});


// const settings = await Notifications.getBadgeCountAsync();
// console.log('通知徽标', settings)


//后台接收消息
export const listNotifications = async (title,body) => {
    await Notifications.scheduleNotificationAsync({
        content: {
            title: title,
            body: body,
        },
        trigger: null,
    });
}
